# **react-router-dom v6**

## **Steps**

1. We have to create our router inside the index.js, so that we can define all of our router in it.
2. We will provide this router to the router provider.
3. Inside the App.js we will be adding outlet where we want to display the pages according to the defined routers.
