import React from "react";

const Body = () => {
  return <h1>Welcome to HomePage</h1>;
};

export default Body;
