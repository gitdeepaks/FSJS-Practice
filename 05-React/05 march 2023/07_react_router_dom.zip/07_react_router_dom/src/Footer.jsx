import React from "react";


const  Footer = ()=>{
  return(
    <div className="footer">
      <h3>@copyright 2023</h3>
    </div>
  )
}
export default Footer;