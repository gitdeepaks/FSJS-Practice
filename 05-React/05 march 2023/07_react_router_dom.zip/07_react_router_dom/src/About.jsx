import React from "react";

const About = () => {
  return <h1>About us page</h1>;
};

export default About;
