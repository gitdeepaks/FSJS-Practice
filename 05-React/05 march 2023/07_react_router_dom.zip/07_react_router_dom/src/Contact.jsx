import React from 'react'

const Contact = () => {
  return (
    <h3 className='text'>Contact us Page</h3>
  )
}

export default Contact